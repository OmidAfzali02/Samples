This is Data science project with the purpose of analyzing iran stock market.
Project is not open source, hence the code should not be revealed.
This project is using streamlit library to create a web application.
At buttom you can see the program abilities:
	-creating stock price chart
	-predicting stock price of many days which user shall define.
	-predicting stock price with 2 different algorithms and their succes rate.
	-creating indicators such as: RSI, MACD, Trendline, SMA and MFI
* sample images of program will be presented.